from machine import Pin 
from machine import Pin, I2C
import machine
import ssd1306 
import dht
import time

i2c = I2C(scl=Pin(22), sda=Pin(21))
oled = ssd1306.SSD1306_I2C(128, 64, i2c, 0x3c)

p15 = Pin(27, Pin.IN)
d=dht.DHT22(p15)

while True:
  d.measure()
  t=d.temperature()
  h=d.humidity()
  print('SUHU =', t, 'C', 'KELEMBABAN =', h, '%')
  time.sleep(1)
  oled.fill(0)
  oled.text("SUHU", 20, 10)
  oled.text(str(t), 40, 20)
  oled.text("C", 60, 20)
  oled.text("KELEMBABAN", 30, 40)
  oled.text(str(h), 40, 55)
  oled.text("%", 60, 55)
  oled.show()